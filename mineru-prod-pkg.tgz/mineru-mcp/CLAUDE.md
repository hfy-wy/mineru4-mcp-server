# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

`mineru-selfhosted-mcp` — an MCP server bridging LLM agents to a **self-hosted MinerU 4.0** parse service (api-server :8000 → router :8002) over its V1 HTTP API. The MCP server deploys at :7000 (`/mcp`); liteLLM (192.168.196.127:4000) exposes `/mineru_selfhosted/mcp` per-server proxy routes; binaries (uploads/downloads) always go direct to :7000, never through liteLLM.

**Environment profiles (single source of endpoint IPs)**: `deploy/env/test.env` (开发测试 192.168.196.10, WSL behind Windows host NAT) and `deploy/env/prod.env` (正式 192.168.210.251). All deploy/client/skill artifacts are `{{VAR}}` templates rendered by `scripts/render_env.sh <profile>` into `deploy/generated/` (gitignored). Never hardcode endpoint IPs in templates/docs — add a variable to the profiles instead. Through liteLLM, tool names are prefixed `mineru_selfhosted-<name>` and client custom headers (e.g. `X-Mineru-User`) need `extra_headers` in the liteLLM config to reach the server.

`mineru4_mcp_pro.py` at the repo root is the legacy single-file reference implementation — kept as reference only, do not extend it.

## Commands

```bash
pip install -e ".[dev]"        # install into venv
pytest tests/                  # unit tests (httpx MockTransport + upload store)
pytest tests/test_v1_client.py # single file

# run (stdio)
mineru-selfhosted-mcp
# run (streamable-http; serves /mcp + /upload + /downloads)
mineru-selfhosted-mcp --transport streamable-http --host 0.0.0.0 --port 7000

# offline e2e: start mock V1 backend, then the server against it
python scripts/mock_mineru_v1.py &
MINERU_BASE_URL=http://127.0.0.1:9999 mineru-selfhosted-mcp -t streamable-http -p 7000
MCP=http://127.0.0.1:7000 bash scripts/smoke_test.sh sample.pdf

# render deploy/client/skill artifacts from an endpoint profile
bash scripts/render_env.sh deploy/env/test.env   # or deploy/env/prod.env
```

No linter/formatter is configured. Python ≥3.10, deps: fastmcp (2.11–3.x), httpx, fastapi, uvicorn, python-multipart, pydantic.

## Architecture (src/mineru_selfhosted_mcp/)

Layers, in call order:

1. **tools.py** — all 10 MCP tool registrations on the FastMCP instance. Every tool returns a plain dict and never raises. `_resolve_sources` normalizes three source kinds into V1 job entries: `upl_…` side-channel handles (lazy V1 upload + sha256 dedup + cached `v1_file_id`), http(s) URLs (server-side fetch passthrough), and server-local paths. `MINERU_TRANSPORT` env distinguishes stdio from http (upload handles are rejected under stdio).
2. **v1_client.py** — `MinerUV1AsyncClient`: one shared `httpx.AsyncClient`; 3-step upload (`POST /v1/uploads` with `sha256sum` dedup → `PUT upload_url` streaming → `POST …/complete`), jobs (`POST /v1/parse/jobs` 202, GET job, list, cancel), streaming `GET /v1/files/{id}/content`. Error envelope → `MinerUV1Error(status_code, message)`.
3. **upload_store.py** — side-channel spool: `UPLOAD_DIR/upl_<id>.bin` + `.json` sidecar; streaming save with inline sha256; size cap (delete partial on abort); TTL sweep; `mark_consumed`/`clear_v1_file_id` for the file_id cache (cleared on 404 from a purged api-server → re-upload).
4. **publish.py** — artifacts to `OUTPUT_DIR/<job_id>/`: markdown saved + inlined (capped by responses.py), zip saved **AND** extracted to `<stem>/` preserving layout, plus a flat `<stem>.md` with image refs rewritten (`images/x.jpg` → `<stem>/images/x.jpg`, neosun-style). download_url = `PUBLIC_BASE_URL + /downloads/<rel>`.
5. **responses.py** — official-style envelope `{status: success|partial_success|error, results[], summary, message}`; content caps 20k/file, 60k total; `tool_ok`/`tool_fail`.
6. **journal.py** — best-effort PostgreSQL job journal (F6): `mineru_jobs` (upsert per job: state/user/client/tier/file_count/file_names/progress/artifact URLs, JSONB detail) + `mineru_job_events` (event timeline); psycopg pool lazy-started, 30s failure backoff; **write failures never affect tool responses**; disabled entirely when `MINERU_PG_DSN` unset. Tools tag the caller via `X-Mineru-User` header > fastmcp client_id > anonymous.
7. **webui.py** — read-only job board: `GET /ui` single-file HTML+JS (stats cards, state/user filters, job table, detail dialog + event timeline, 5s auto-refresh) + `/ui/api/summary|jobs|jobs/{id}` JSON endpoints; reads journal tables only.
8. **server.py** — assembly. `build_mcp()` creates FastMCP + tools + journal; `build_app()` mounts: sidechannel routes → webui `/ui` → `/downloads` StaticFiles → mcp_app at `/` LAST (parent routes match first, MCP at `/mcp`). **The FastAPI app must take `lifespan=mcp_app.lifespan`** or the MCP session manager task group never starts (503). Also runs the 10-min upload TTL sweeper in the lifespan.
9. **sidechannel.py** — HTTP routes (NOT MCP tools): `POST /upload` (multipart, repeatable `file` field → UploadStore), `GET /upload/{id}/status`, `DELETE /upload/{id}`, `GET /` info, `GET /healthz`.
10. **security.py** — pure-ASGI bearer middleware covering `/mcp` + `/upload` (avoids fastmcp auth API churn); `/downloads`, `/healthz`, `/ui` exempt. No-op when `MINERU_MCP_TOKEN` unset.
11. **config.py** — frozen `Settings.from_env()`; no mutable globals. `MINERU_BASE_URL` (default router :8002), `MINERU_API_KEY`, `MINERU_MCP_TOKEN`, dirs, limits, TTLs, `MINERU_PG_DSN` (journal), `MINERU_WEBUI_ENABLED`.
12. **filetypes.py** — vendored ext→mime table + PARSEABLE/FLASH_ONLY sets (deliberately not importing the heavy `mineru` package).

## V1 protocol facts (verified against MinerU 4.0 api_server.py)

- Upload dedup: `POST /v1/uploads` with `sha256sum` returns `status:"completed"` + embedded `file.id` when the blob exists — skip PUT/complete.
- Job statuses: `queued|running|completed|partial|failed|canceled`; per-file `output_files: {format: {file_id, bytes}}` with unrequested formats as explicit `null` values; list = `GET /v1/parse/jobs` (cursor params `status`/`limit`/`after`/`order`/`created_after`, response `{object, data[], first_id, last_id, has_more}`); cancel = `DELETE /v1/parse/jobs/{id}` (409 on already-finished jobs).
- Local output formats: `markdown/middle_json/structured_content/zip` only — requesting html/latex/docx locally fails with **403** "Output format 'X' requires an API key". `ocr_mode`: `auto|txt|ocr`. `page_range` PDF-only, grammar `N|N-M|1,3,5-7|all|rN` reverse.
- sha256 dedup on re-upload: `POST /v1/uploads` returns `status:"completed"` + embedded **new** file id (bytes not re-transferred, but a fresh file record is allocated — code must use the returned id, not assume the old one).
- Limits: 200MB/file, 1000 pages, 100 files/job, server concurrency default 1. Poll 2s → ×1.5 → 30s cap.
- Auth: with `--api-key`, everything except health/models/tiers needs `Authorization: Bearer`.

## Key invariants

- Tools never raise; failures become `error` rows / `tool_fail` dicts.
- Content caps: 20k/file, 60k total; full markdown always on disk (`extract_path`).
- Binary data never enters MCP tool arguments — side-channel only, works through liteLLM because binaries go direct to :7000.
- `MINERU_PUBLIC_BASE_URL` stays pinned to :7000 even when MCP traffic is proxied — tool responses advertise direct upload/download URLs.
- zip = save original AND extract; flat md refs fixed so `/downloads/<job_id>/<stem>/images/…` resolves.
- Journal writes are best-effort and never block or fail a tool call; `submit_job` projects entries to protocol keys only (`display_name` metadata never leaves the server).
- fastmcp shim: `http_app()` vs `streamable_http_app()` handled in `server._mcp_asgi_app`.

## Tests

`tests/test_v1_client.py` (MockTransport: dedup hit, 3-step, error mapping, streaming, list params), `tests/test_upload_store.py` (save/caps/TTL/cache/unsafe ids), `tests/test_journal.py` (fake-pool SQL logic: upsert, progress, published, failure backoff — no real PostgreSQL needed). E2E against the mock backend in `scripts/mock_mineru_v1.py`; two-user journal E2E in `scripts/mcp_f6_e2e.py` (verified 2026-09-27 against real PG 16 in WSL docker — see `docs/pg_verification_checklist.md`). Windows note: psycopg async requires SelectorEventLoop — `server.run()` forces selector policy + `uvicorn.run(..., loop="none")` on win32 (Linux unaffected).
